// LAB7.2: ES6 Class (Car)
// Tạo lại đối tượng Car sử dụng ES6 class:

class Car {
  constructor(make, speed) {
    this.make = make;
    this.speed = speed;
  }

  // Phương thức tăng tốc
  accelerate() {
    this.speed += 10;
    console.log(`${this.make} is going at ${this.speed} km/h`);
  }

  // Phương thức giảm tốc
  brake() {
    this.speed -= 5;
    console.log(`${this.make} is going at ${this.speed} km/h`);
  }

  // Getter cho speedUS (tốc độ tính theo mph)
  get speedUS() {
    return this.speed / 1.6;
  }

  // Setter cho speedUS (cập nhật tốc độ theo mph)
  set speedUS(speed) {
    this.speed = speed * 1.6;
  }
}

// Tạo đối tượng Car và kiểm tra
const ford = new Car('Ford', 120);
ford.accelerate();
ford.brake();
console.log(ford.speedUS);  // In tốc độ theo mph
ford.speedUS = 50;          // Cập nhật tốc độ theo mph
console.log(ford);