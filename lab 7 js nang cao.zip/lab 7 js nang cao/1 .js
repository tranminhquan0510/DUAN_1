// LAB7.1: Constructor Function (Car)
// Khởi tạo đối tượng ô tô (Car):

// Constructor function for Car
function Car(make, speed) {
  this.make = make;
  this.speed = speed;
}

// Phương thức tăng tốc
Car.prototype.accelerate = function() {
  this.speed += 10;
  console.log(`${this.make} is going at ${this.speed} km/h`);
};

// Phương thức giảm tốc
Car.prototype.brake = function() {
  this.speed -= 5;
  console.log(`${this.make} is going at ${this.speed} km/h`);
};

// Tạo đối tượng Car
const bmw = new Car('BMW', 120);
const mercedes = new Car('Mercedes', 95);

// Test phương thức
bmw.accelerate();
bmw.brake();
mercedes.accelerate();
mercedes.brake();